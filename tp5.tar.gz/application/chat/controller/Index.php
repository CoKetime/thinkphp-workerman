<?php
/**
 * Created by IntelliJ IDEA.
 * User: li914
 * Date: 18-8-13
 * Time: 上午10:00
 */

namespace app\chat\controller;


use think\Controller;

class Index extends Controller
{
    public function index(){
        return view();
    }
}