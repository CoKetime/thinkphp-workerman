<?php
/**
 * Created by IntelliJ IDEA.
 * User: li914
 * Date: 18-8-13
 * Time: 上午10:00
 */

namespace app\chat\controller;

use GatewayClient\Gateway;
use think\Controller;
use think\facade\Request;
use think\Route;
// 引入七牛鉴权类
use Qiniu\Auth;
// 引入七牛上传类
use Qiniu\Storage\UploadManager;
use think\facade\Config;

class Upload extends Controller
{
  public function  index(){
 	
  }
      //发送群组信息
    public function uploadfile(){
	  $data = input('post.');
          // 要上传文件的临时文件
        $file = $_FILES['file']['tmp_name'];
        $pathinfo = pathinfo($_FILES['file']['name']);
        // 通过pathinfo函数获取图片后缀名
        $ext = $pathinfo['extension'];
        $accessKey = config('ACCESSKEY');
        $secretKey = config('SECRETKEY');
        // 构建鉴权对象
        $auth = new Auth($accessKey, $secretKey);
        // 要上传的空间
        $bucket = config('BUCKET');
        $domain = config('DOMAIN');
        $token = $auth->uploadToken($bucket);
        // 上传到七牛后保存的文件名
        $filename = date('Y').'/'.date('m').'/'.substr(md5($file),8,5).date('Ymd').rand(0,9999).'.'.$ext;
        // 初始化UploadManager类
        $uploadMgr = new UploadManager();
        list($res,$err) = $uploadMgr->putFile($token,$filename,$file);
        if($err !== null){
            return null;
        }else{
           $url = $domain.$filename;
        }
        $to_client_id=$data['to_client_id'];
        $to_client_name=$data['to_client_name'];
        $form_client_id=$data['form_client_id'];
        $form_client_name=$data['form_client_name'];
        $content= $url;
        $room_id=$data['room_id'];
       // $form_client_header=$data['form_client_header'];头像
        $time=$data['time'];
        $msg_type=$data['msg_type'];
       $msg='{"type":"say","form_client_id":"'.$form_client_id.'","form_client_name":"' .$form_client_name.'","content":"'.$content.'","to_client_id":"'.$to_client_id.'","to_client_name":"'.$to_client_name.'","time":"'.$time.'",'.'"msg_type":"'.$msg_type.'"}';
        try{
            Gateway::sendToGroup($room_id,$msg,array($form_client_id));
        }catch (\Exception $e){
            var_dump( $content);
        }
      return json_encode(['msg'=>'语音发送']);
 	
    }
}