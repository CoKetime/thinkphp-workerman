<?php
/**
 * Created by IntelliJ IDEA.
 * User: li914
 * Date: 18-8-14
 * Time: 上午10:08
 */

return[
    'success'=>['code'=>1,'msg'=>'ok','status'=>'ok','time'=>date('H:i:s'),'result'=>[]],
    'fail'=>['code'=>0,'msg'=>'fail','status'=>'fail','time'=>date('H:i:s'),'result'=>[]],
];