//菜单
exports.commonapi = "commonapi"


